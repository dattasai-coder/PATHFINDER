"""
Scratch script to preview realistic 3D highway perspective SVGs for Virtual Guide.
"""
import html
import re

def build_realistic_svg(direction_type: str, headline: str = "", road_name: str = "", distance_str: str = "", step_num: int = 1, total_steps: int = 1) -> str:
    dt = direction_type.upper()
    road_clean = road_name.strip() if road_name else ""
    if not road_clean:
        # extract road from headline if present
        m = re.search(r'(?:onto|on|along)\s+([^,]+)', headline, re.IGNORECASE)
        road_clean = m.group(1).strip() if m else "Highway Corridor"
    
    # Cap road name length for neat display on overhead sign
    road_display = road_clean[:24].upper()
    dist_display = distance_str if distance_str else "Ahead"
    
    # Shared SVG Defs: Gradients, Filters, Shadows
    defs = """
    <defs>
        <!-- Gradients -->
        <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#050a14"/>
            <stop offset="45%" stop-color="#0b182d"/>
            <stop offset="85%" stop-color="#152b4b"/>
            <stop offset="100%" stop-color="#1f3b64"/>
        </linearGradient>
        <linearGradient id="horizonGlow" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.3"/>
            <stop offset="100%" stop-color="#0c192c" stop-opacity="0"/>
        </linearGradient>
        <linearGradient id="terrainGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#0a1815"/>
            <stop offset="50%" stop-color="#0c231c"/>
            <stop offset="100%" stop-color="#06120e"/>
        </linearGradient>
        <linearGradient id="asphaltGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#1e293b"/>
            <stop offset="50%" stop-color="#182234"/>
            <stop offset="100%" stop-color="#0f172a"/>
        </linearGradient>
        <linearGradient id="arCarpetLeft" x1="100%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stop-color="#00f2fe" stop-opacity="0.95"/>
            <stop offset="60%" stop-color="#10b981" stop-opacity="0.85"/>
            <stop offset="100%" stop-color="#059669" stop-opacity="0.75"/>
        </linearGradient>
        <linearGradient id="arCarpetRight" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#00f2fe" stop-opacity="0.95"/>
            <stop offset="60%" stop-color="#10b981" stop-opacity="0.85"/>
            <stop offset="100%" stop-color="#059669" stop-opacity="0.75"/>
        </linearGradient>
        <linearGradient id="arCarpetStraight" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stop-color="#00f2fe" stop-opacity="0.95"/>
            <stop offset="65%" stop-color="#10b981" stop-opacity="0.85"/>
            <stop offset="100%" stop-color="#059669" stop-opacity="0.5"/>
        </linearGradient>
        <linearGradient id="headlightBeam" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stop-color="#ffffff" stop-opacity="0.35"/>
            <stop offset="40%" stop-color="#38bdf8" stop-opacity="0.18"/>
            <stop offset="100%" stop-color="#38bdf8" stop-opacity="0"/>
        </linearGradient>
        <linearGradient id="signGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#005d38"/>
            <stop offset="100%" stop-color="#004328"/>
        </linearGradient>
        <linearGradient id="hudGlassGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="rgba(15, 23, 42, 0.88)"/>
            <stop offset="100%" stop-color="rgba(7, 15, 30, 0.94)"/>
        </linearGradient>
        
        <!-- Filters -->
        <filter id="neonGlowCyan" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" result="blur"/>
            <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
        </filter>
        <filter id="neonGlowEmerald" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="5" result="blur"/>
            <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
        </filter>
        <filter id="redLightGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="6" result="blur"/>
            <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
        </filter>
        <filter id="amberBlinkerGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="5" result="blur"/>
            <feMerge>
                <feMergeNode in="blur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
        </filter>
        <filter id="dropShadow" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000000" flood-opacity="0.6"/>
        </filter>
    </defs>
    """

    # Shared Environment: Sky, Mountain Silhouettes, Horizon Mist
    sky_and_horizon = """
    <!-- Sky Background -->
    <rect width="760" height="135" fill="url(#skyGrad)"/>
    
    <!-- Stars / Ambient Night Sky Particles -->
    <circle cx="85" cy="22" r="1" fill="#ffffff" opacity="0.65"/>
    <circle cx="160" cy="38" r="1.2" fill="#bae6fd" opacity="0.8"/>
    <circle cx="270" cy="18" r="0.8" fill="#ffffff" opacity="0.5"/>
    <circle cx="430" cy="28" r="1.2" fill="#ffffff" opacity="0.7"/>
    <circle cx="560" cy="15" r="1.5" fill="#bae6fd" opacity="0.85"/>
    <circle cx="680" cy="32" r="1" fill="#ffffff" opacity="0.6"/>
    <circle cx="720" cy="20" r="0.8" fill="#ffffff" opacity="0.5"/>

    <!-- Distant Mountain Skyline -->
    <polygon points="0,135 45,118 110,126 195,112 280,124 370,108 460,122 550,114 640,125 710,116 760,126 760,135 0,135" fill="#0c182b" opacity="0.85"/>
    <polygon points="0,135 80,124 165,116 250,128 340,118 430,127 520,119 610,126 700,120 760,130 760,135 0,135" fill="#091322" opacity="0.95"/>

    <!-- Horizon Twilight Glow -->
    <rect y="105" width="760" height="30" fill="url(#horizonGlow)"/>

    <!-- Ground & Roadside Verges -->
    <rect y="135" width="760" height="165" fill="url(#terrainGrad)"/>
    """

    # HUD Elements helper
    def render_hud_telemetry(title: str, sub: str, icon: str = "⬅️", lane_type: str = "left"):
        left_lane_active = (lane_type == "left")
        right_lane_active = (lane_type == "right")
        straight_lane_active = (lane_type == "straight")
        
        return f"""
        <!-- Top-Left Navigation Cockpit HUD Card -->
        <g filter="url(#dropShadow)" transform="translate(18, 14)">
            <rect width="260" height="58" rx="10" fill="url(#hudGlassGrad)" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1.2"/>
            <rect x="2" y="2" width="54" height="54" rx="8" fill="rgba(2, 132, 199, 0.25)" stroke="rgba(56, 189, 248, 0.5)" stroke-width="1"/>
            <text x="29" y="38" text-anchor="middle" font-size="26">{icon}</text>
            <text x="68" y="24" fill="#38bdf8" font-size="10" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif" letter-spacing="1">NEXT MANEUVER • {dist_display.upper()}</text>
            <text x="68" y="42" fill="#ffffff" font-size="14" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">{title}</text>
            <text x="68" y="52" fill="#94a3b8" font-size="8.5" font-weight="600" font-family="'Segoe UI', Roboto, sans-serif">{sub[:32]}</text>
        </g>

        <!-- Top-Right Telemetry Badges -->
        <g filter="url(#dropShadow)" transform="translate(565, 14)">
            <rect width="177" height="42" rx="8" fill="url(#hudGlassGrad)" stroke="rgba(56, 189, 248, 0.3)" stroke-width="1.2"/>
            <!-- Speed Badge -->
            <rect x="8" y="8" width="26" height="26" rx="13" fill="#ffffff" stroke="#ef4444" stroke-width="2.5"/>
            <text x="21" y="25" text-anchor="middle" fill="#0f172a" font-size="11" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">60</text>
            <!-- GPS RTK Lock Status -->
            <circle cx="50" cy="21" r="4" fill="#10b981" filter="url(#neonGlowEmerald)"/>
            <text x="60" y="20" fill="#34d399" font-size="9" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">GPS LOCKED</text>
            <text x="60" y="30" fill="#94a3b8" font-size="8" font-weight="600" font-family="'Segoe UI', Roboto, sans-serif">REAL-TIME HD MAP</text>
            <text x="148" y="25" fill="#38bdf8" font-size="10" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">STEP {step_num}</text>
        </g>

        <!-- Bottom Center Lane Assist Guidance Widget -->
        <g filter="url(#dropShadow)" transform="translate(265, 252)">
            <rect width="230" height="36" rx="8" fill="url(#hudGlassGrad)" stroke="rgba(56, 189, 248, 0.35)" stroke-width="1"/>
            
            <!-- Lane 1 (Left) -->
            <rect x="6" y="5" width="105" height="26" rx="5" 
                  fill="{'rgba(14, 165, 233, 0.35)' if left_lane_active else 'rgba(15, 23, 42, 0.6)'}" 
                  stroke="{'#38bdf8' if left_lane_active else 'rgba(148, 163, 184, 0.25)'}" stroke-width="{'1.5' if left_lane_active else '1'}"/>
            <text x="18" y="22" font-size="13">⬅️</text>
            <text x="36" y="21" fill="{'#ffffff' if left_lane_active else '#94a3b8'}" font-size="9" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">
                {'TURN LANE' if left_lane_active else 'LEFT ONLY'}
            </text>
            {f'<circle cx="98" cy="18" r="3" fill="#10b981" filter="url(#neonGlowEmerald)"/>' if left_lane_active else ''}

            <!-- Lane 2 (Right/Straight) -->
            <rect x="119" y="5" width="105" height="26" rx="5" 
                  fill="{'rgba(14, 165, 233, 0.35)' if (right_lane_active or straight_lane_active) else 'rgba(15, 23, 42, 0.6)'}" 
                  stroke="{'#38bdf8' if (right_lane_active or straight_lane_active) else 'rgba(148, 163, 184, 0.25)'}" stroke-width="{'1.5' if (right_lane_active or straight_lane_active) else '1'}"/>
            <text x="131" y="22" font-size="13">{'➡️' if right_lane_active else '⬆️'}</text>
            <text x="149" y="21" fill="{'#ffffff' if (right_lane_active or straight_lane_active) else '#94a3b8'}" font-size="9" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">
                {'EXIT LANE' if right_lane_active else 'THRU LANE'}
            </text>
            {f'<circle cx="211" cy="18" r="3" fill="#10b981" filter="url(#neonGlowEmerald)"/>' if (right_lane_active or straight_lane_active) else ''}
        </g>
        """

    # 1. SCENE: TURN LEFT
    if dt == "LEFT" or "left" in headline.lower():
        return f"""<svg viewBox="0 0 760 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block; max-height: 290px; background: #050a14;">
        {defs}
        {sky_and_horizon}

        <!-- Road Network: Straight Highway with Broad Left Curve Junction -->
        <!-- Main Receding Highway -->
        <polygon points="345,135 415,135 590,300 230,300" fill="url(#asphaltGrad)"/>
        
        <!-- Curving Left Branching Road (3D Curved Tarmac) -->
        <path d="M 370 135 Q 310 160 120 185 L 0 195 L 0 255 L 140 245 Q 310 235 440 300 L 320 300 Q 230 220 0 215" fill="#152033" opacity="0.95"/>
        <path d="M 370 135 Q 310 165 140 195 L 0 205 L 0 245 L 150 235 Q 320 215 450 300" fill="url(#asphaltGrad)"/>

        <!-- Road Curbs (Red and White alternating safety curbs along the bend) -->
        <path d="M 366 135 Q 306 165 136 195 L 0 205" fill="none" stroke="#dc2626" stroke-width="4"/>
        <path d="M 366 135 Q 306 165 136 195 L 0 205" fill="none" stroke="#ffffff" stroke-width="4" stroke-dasharray="14,14"/>

        <!-- Road Shoulder Fog Lines -->
        <line x1="415" y1="135" x2="590" y2="300" stroke="#f8fafc" stroke-width="2.5" opacity="0.8"/>
        
        <!-- Receding Center Dashed Lane Markings (Main Highway) -->
        <line x1="380" y1="135" x2="380" y2="148" stroke="#facc15" stroke-width="1.8" opacity="0.7"/>
        <line x1="382" y1="156" x2="384" y2="175" stroke="#facc15" stroke-width="2.4" opacity="0.75"/>
        <line x1="387" y1="187" x2="391" y2="216" stroke="#facc15" stroke-width="3.2" opacity="0.8"/>
        <line x1="395" y1="235" x2="403" y2="280" stroke="#facc15" stroke-width="4.5" opacity="0.85"/>

        <!-- 3D Augmented Reality Navigation Carpet (Glowing Green/Cyan Ribbon Turning Left) -->
        <path d="M 410 300 Q 320 220 180 208 L 0 218 L 0 236 L 195 226 Q 345 236 450 300 Z" fill="url(#arCarpetLeft)" filter="url(#neonGlowEmerald)" opacity="0.9"/>
        
        <!-- Directional 3D AR Forward Chevrons on Carpet -->
        <g fill="#ffffff" opacity="0.95" filter="url(#dropShadow)">
            <!-- Chevron 1 (Foreground) -->
            <polygon points="360,266 385,255 376,252 355,261"/>
            <polygon points="360,266 376,276 384,272 366,263"/>
            <!-- Chevron 2 (Mid-turn) -->
            <polygon points="275,236 295,229 288,226 270,233"/>
            <polygon points="275,236 288,244 294,241 280,234"/>
            <!-- Chevron 3 (Exit turn) -->
            <polygon points="170,218 185,214 180,211 166,215"/>
            <polygon points="170,218 180,223 184,221 174,216"/>
            <!-- Chevron 4 (Far) -->
            <polygon points="80,218 92,216 88,214 78,216"/>
            <polygon points="80,218 88,221 91,220 83,217"/>
        </g>

        <!-- Modern Highway Light Poles (with volumetric illumination) -->
        <!-- Pole 1 (Right Highway Shoulder) -->
        <path d="M 545 130 Q 550 85 525 80" fill="none" stroke="#64748b" stroke-width="3"/>
        <line x1="545" y1="130" x2="552" y2="225" stroke="#475569" stroke-width="3"/>
        <ellipse cx="523" cy="80" rx="6" ry="2.5" fill="#38bdf8"/>
        <ellipse cx="480" cy="225" rx="75" ry="24" fill="#38bdf8" opacity="0.12" filter="url(#neonGlowCyan)"/>

        <!-- Pole 2 (Left Corner) -->
        <path d="M 125 150 Q 120 100 145 95" fill="none" stroke="#64748b" stroke-width="2.5"/>
        <line x1="125" y1="150" x2="120" y2="195" stroke="#475569" stroke-width="2.5"/>
        <ellipse cx="145" cy="95" rx="5" ry="2" fill="#facc15"/>
        <ellipse cx="155" cy="210" rx="55" ry="18" fill="#facc15" opacity="0.14" filter="url(#amberBlinkerGlow)"/>

        <!-- Realistic Guardrail with Reflectors along the right highway curve -->
        <line x1="422" y1="135" x2="605" y2="300" stroke="#64748b" stroke-width="4.5" opacity="0.7"/>
        <line x1="424" y1="138" x2="607" y2="300" stroke="#94a3b8" stroke-width="1.8" opacity="0.8"/>
        <!-- Amber Cat's-Eye Reflectors -->
        <circle cx="452" cy="165" r="1.8" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="492" cy="202" r="2.2" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="542" cy="246" r="2.8" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>

        <!-- Highway Trees & Green Foliage along shoulders -->
        <g opacity="0.85">
            <!-- Left trees -->
            <path d="M 70 170 C 55 140 85 130 95 140 C 115 125 130 145 125 165 C 130 175 100 185 70 170 Z" fill="#0c2e22"/>
            <path d="M 18 190 C 5 160 30 150 40 160 C 55 148 70 165 65 180 C 70 190 40 200 18 190 Z" fill="#08231a"/>
            <!-- Right trees -->
            <path d="M 640 150 C 625 125 655 115 665 125 C 685 110 705 130 700 148 C 705 158 675 168 640 150 Z" fill="#0c2e22"/>
            <path d="M 690 165 C 680 140 705 135 715 142 C 730 130 745 145 740 160 Z" fill="#08231a"/>
        </g>

        <!-- Overhead Highway Green Directional Sign Gantry -->
        <g filter="url(#dropShadow)" transform="translate(190, 72)">
            <!-- Metal Truss Structure -->
            <line x1="-10" y1="6" x2="390" y2="6" stroke="#475569" stroke-width="3"/>
            <line x1="-10" y1="18" x2="390" y2="18" stroke="#475569" stroke-width="2"/>
            <!-- Gantry Mount Poles -->
            <line x1="0" y1="6" x2="0" y2="60" stroke="#334155" stroke-width="3.5"/>
            <line x1="380" y1="6" x2="380" y2="60" stroke="#334155" stroke-width="3.5"/>
            
            <!-- Left Turn Highway Sign Panel -->
            <rect x="25" y="0" width="180" height="42" rx="4" fill="url(#signGrad)" stroke="#f8fafc" stroke-width="1.8"/>
            <text x="36" y="16" fill="#facc15" font-size="9" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">⬅️ EXIT ONLY • {dist_display.upper()}</text>
            <text x="36" y="32" fill="#ffffff" font-size="12" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">{road_display}</text>

            <!-- Right Thru Highway Sign Panel -->
            <rect x="215" y="0" width="145" height="42" rx="4" fill="url(#signGrad)" stroke="#f8fafc" stroke-width="1.5" opacity="0.9"/>
            <text x="226" y="16" fill="#ffffff" font-size="8.5" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">⬆️ THRU CORRIDOR</text>
            <text x="226" y="32" fill="#bae6fd" font-size="11" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">EXPRESSWAY</text>
        </g>

        <!-- Driver's Vehicle (Chase / Hood Perspective with Glowing LED Taillights & Left Blinker) -->
        <g filter="url(#dropShadow)" transform="translate(355, 230)">
            <!-- Car Body Aerodynamic Shape -->
            <path d="M 12 28 C 12 12 28 4 48 4 C 68 4 84 12 84 28 L 92 65 C 92 68 88 70 82 70 L 14 70 C 8 70 4 68 4 65 Z" fill="#0f1f38" stroke="#38bdf8" stroke-width="1.2"/>
            <!-- Rear Windshield Glass -->
            <path d="M 22 26 C 22 15 32 10 48 10 C 64 10 74 15 74 26 L 78 40 L 18 40 Z" fill="#050e1c" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1"/>
            
            <!-- Left Taillight (Red LED Bar) -->
            <rect x="12" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <!-- Right Taillight (Red LED Bar) -->
            <rect x="62" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            
            <!-- Active Left Amber Turn Blinker (Flashing) -->
            <circle cx="8" cy="51" r="5.5" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
            <circle cx="8" cy="51" r="2.5" fill="#ffffff"/>

            <!-- License Plate -->
            <rect x="37" y="52" width="22" height="8" rx="1.5" fill="#ffffff"/>
            <text x="48" y="58" text-anchor="middle" fill="#0f172a" font-size="5.5" font-weight="900" font-family="'Segoe UI', sans-serif">AP 07</text>
        </g>

        {render_hud_telemetry("TURN LEFT ⬅️", road_clean, icon="⬅️", lane_type="left")}
        </svg>"""

    # 2. SCENE: TURN RIGHT
    elif dt == "RIGHT" or "right" in headline.lower():
        return f"""<svg viewBox="0 0 760 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block; max-height: 290px; background: #050a14;">
        {defs}
        {sky_and_horizon}

        <!-- Road Network: Straight Highway with Broad Right Curve Junction -->
        <polygon points="345,135 415,135 530,300 170,300" fill="url(#asphaltGrad)"/>
        
        <!-- Curving Right Branching Road -->
        <path d="M 390 135 Q 450 160 640 185 L 760 195 L 760 255 L 620 245 Q 450 235 320 300 L 440 300 Q 530 220 760 215" fill="#152033" opacity="0.95"/>
        <path d="M 390 135 Q 450 165 620 195 L 760 205 L 760 245 L 610 235 Q 440 215 310 300" fill="url(#asphaltGrad)"/>

        <!-- Road Curbs -->
        <path d="M 394 135 Q 454 165 624 195 L 760 205" fill="none" stroke="#dc2626" stroke-width="4"/>
        <path d="M 394 135 Q 454 165 624 195 L 760 205" fill="none" stroke="#ffffff" stroke-width="4" stroke-dasharray="14,14"/>

        <!-- Road Shoulder Fog Lines -->
        <line x1="345" y1="135" x2="170" y2="300" stroke="#f8fafc" stroke-width="2.5" opacity="0.8"/>
        
        <!-- Receding Center Dashed Lane Markings -->
        <line x1="380" y1="135" x2="380" y2="148" stroke="#facc15" stroke-width="1.8" opacity="0.7"/>
        <line x1="378" y1="156" x2="376" y2="175" stroke="#facc15" stroke-width="2.4" opacity="0.75"/>
        <line x1="373" y1="187" x2="369" y2="216" stroke="#facc15" stroke-width="3.2" opacity="0.8"/>
        <line x1="365" y1="235" x2="357" y2="280" stroke="#facc15" stroke-width="4.5" opacity="0.85"/>

        <!-- 3D Augmented Reality Navigation Carpet (Right Curve) -->
        <path d="M 350 300 Q 440 220 580 208 L 760 218 L 760 236 L 565 226 Q 415 236 310 300 Z" fill="url(#arCarpetRight)" filter="url(#neonGlowEmerald)" opacity="0.9"/>
        
        <!-- Directional 3D AR Forward Chevrons -->
        <g fill="#ffffff" opacity="0.95" filter="url(#dropShadow)">
            <polygon points="400,266 375,255 384,252 405,261"/>
            <polygon points="400,266 384,276 376,272 394,263"/>
            <polygon points="485,236 465,229 472,226 490,233"/>
            <polygon points="485,236 472,244 466,241 480,234"/>
            <polygon points="590,218 575,214 580,211 594,215"/>
            <polygon points="590,218 580,223 576,221 586,216"/>
            <polygon points="680,218 668,216 672,214 682,216"/>
        </g>

        <!-- Modern Highway Light Poles -->
        <path d="M 215 130 Q 210 85 235 80" fill="none" stroke="#64748b" stroke-width="3"/>
        <line x1="215" y1="130" x2="208" y2="225" stroke="#475569" stroke-width="3"/>
        <ellipse cx="237" cy="80" rx="6" ry="2.5" fill="#38bdf8"/>
        <ellipse cx="280" cy="225" rx="75" ry="24" fill="#38bdf8" opacity="0.12" filter="url(#neonGlowCyan)"/>

        <!-- Guardrail along left shoulder -->
        <line x1="338" y1="135" x2="155" y2="300" stroke="#64748b" stroke-width="4.5" opacity="0.7"/>
        <line x1="336" y1="138" x2="153" y2="300" stroke="#94a3b8" stroke-width="1.8" opacity="0.8"/>
        <circle cx="308" cy="165" r="1.8" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="268" cy="202" r="2.2" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="218" cy="246" r="2.8" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>

        <!-- Overhead Highway Directional Sign Gantry -->
        <g filter="url(#dropShadow)" transform="translate(190, 72)">
            <line x1="-10" y1="6" x2="390" y2="6" stroke="#475569" stroke-width="3"/>
            <line x1="-10" y1="18" x2="390" y2="18" stroke="#475569" stroke-width="2"/>
            <line x1="0" y1="6" x2="0" y2="60" stroke="#334155" stroke-width="3.5"/>
            <line x1="380" y1="6" x2="380" y2="60" stroke="#334155" stroke-width="3.5"/>
            
            <rect x="25" y="0" width="145" height="42" rx="4" fill="url(#signGrad)" stroke="#f8fafc" stroke-width="1.5" opacity="0.9"/>
            <text x="36" y="16" fill="#ffffff" font-size="8.5" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">⬆️ THRU CORRIDOR</text>
            <text x="36" y="32" fill="#bae6fd" font-size="11" font-weight="800" font-family="'Segoe UI', Roboto, sans-serif">EXPRESSWAY</text>

            <rect x="175" y="0" width="180" height="42" rx="4" fill="url(#signGrad)" stroke="#f8fafc" stroke-width="1.8"/>
            <text x="186" y="16" fill="#facc15" font-size="9" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">➡️ EXIT ONLY • {dist_display.upper()}</text>
            <text x="186" y="32" fill="#ffffff" font-size="12" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">{road_display}</text>
        </g>

        <!-- Driver's Vehicle with Right Blinker Active -->
        <g filter="url(#dropShadow)" transform="translate(305, 230)">
            <path d="M 12 28 C 12 12 28 4 48 4 C 68 4 84 12 84 28 L 92 65 C 92 68 88 70 82 70 L 14 70 C 8 70 4 68 4 65 Z" fill="#0f1f38" stroke="#38bdf8" stroke-width="1.2"/>
            <path d="M 22 26 C 22 15 32 10 48 10 C 64 10 74 15 74 26 L 78 40 L 18 40 Z" fill="#050e1c" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1"/>
            <rect x="12" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <rect x="62" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <circle cx="88" cy="51" r="5.5" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
            <circle cx="88" cy="51" r="2.5" fill="#ffffff"/>
            <rect x="37" y="52" width="22" height="8" rx="1.5" fill="#ffffff"/>
            <text x="48" y="58" text-anchor="middle" fill="#0f172a" font-size="5.5" font-weight="900" font-family="'Segoe UI', sans-serif">AP 07</text>
        </g>

        {render_hud_telemetry("TURN RIGHT ➡️", road_clean, icon="➡️", lane_type="right")}
        </svg>"""

    # 3. SCENE: ARRIVE (Celebratory Arrival at Real Destination)
    elif dt == "ARRIVE" or "arrive" in headline.lower():
        return f"""<svg viewBox="0 0 760 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block; max-height: 290px; background: #050a14;">
        {defs}
        {sky_and_horizon}

        <!-- Receding Boulevard Approaching Modern Architectural Campus/Destination -->
        <polygon points="345,135 415,135 600,300 160,300" fill="url(#asphaltGrad)"/>
        <line x1="345" y1="135" x2="160" y2="300" stroke="#f8fafc" stroke-width="3" opacity="0.85"/>
        <line x1="415" y1="135" x2="600" y2="300" stroke="#f8fafc" stroke-width="3" opacity="0.85"/>

        <!-- Destination Grand Arch / Plaza Building Silhouette -->
        <g transform="translate(260, 75)" opacity="0.95">
            <rect x="0" y="25" width="240" height="35" rx="4" fill="#0f2744" stroke="#38bdf8" stroke-width="1.8"/>
            <rect x="15" y="8" width="210" height="18" rx="3" fill="#07172b" stroke="#38bdf8" stroke-width="1"/>
            <text x="120" y="21" text-anchor="middle" fill="#38bdf8" font-size="9" font-weight="900" font-family="'Segoe UI', sans-serif" letter-spacing="2">★ DESTINATION ARRIVAL PLAZA ★</text>
            <text x="120" y="47" text-anchor="middle" fill="#ffffff" font-size="14" font-weight="900" font-family="'Segoe UI', sans-serif">{road_display}</text>
            <!-- Arch Pillars -->
            <rect x="5" y="60" width="25" height="40" fill="#0d1b2e" stroke="#38bdf8" stroke-width="1"/>
            <rect x="210" y="60" width="25" height="40" fill="#0d1b2e" stroke="#38bdf8" stroke-width="1"/>
        </g>

        <!-- Glowing Vertical Holographic Light Column -->
        <rect x="375" y="20" width="10" height="180" fill="url(#arCarpetStraight)" filter="url(#neonGlowCyan)" opacity="0.85"/>
        <line x1="380" y1="15" x2="380" y2="200" stroke="#ffffff" stroke-width="3" filter="url(#neonGlowCyan)"/>

        <!-- Floating 3D Holographic Destination Pin -->
        <g filter="url(#neonGlowEmerald)" transform="translate(380, 50)">
            <circle cx="0" cy="0" r="18" fill="#10b981" stroke="#ffffff" stroke-width="2.5"/>
            <text x="0" y="7" text-anchor="middle" font-size="16">🏁</text>
        </g>

        <!-- Concentric Glowing Arrival Target Rings on Tarmac -->
        <ellipse cx="380" cy="205" rx="70" ry="20" fill="none" stroke="#10b981" stroke-width="3.5" filter="url(#neonGlowEmerald)"/>
        <ellipse cx="380" cy="205" rx="110" ry="32" fill="none" stroke="#38bdf8" stroke-width="2" filter="url(#neonGlowCyan)" stroke-dasharray="10,8"/>
        <ellipse cx="380" cy="205" rx="150" ry="44" fill="none" stroke="#facc15" stroke-width="1.5" opacity="0.6"/>

        <!-- Welcoming Celebration Lights & Palms -->
        <g opacity="0.85">
            <path d="M 120 180 C 105 140 145 130 155 140 C 180 125 195 150 190 175 Z" fill="#0d3326"/>
            <path d="M 570 180 C 555 140 595 130 605 140 C 630 125 645 150 640 175 Z" fill="#0d3326"/>
        </g>

        <!-- Driver Vehicle Safely Parked at Destination -->
        <g filter="url(#dropShadow)" transform="translate(335, 225)">
            <path d="M 12 28 C 12 12 28 4 48 4 C 68 4 84 12 84 28 L 92 65 C 92 68 88 70 82 70 L 14 70 C 8 70 4 68 4 65 Z" fill="#0f1f38" stroke="#10b981" stroke-width="1.8"/>
            <path d="M 22 26 C 22 15 32 10 48 10 C 64 10 74 15 74 26 L 78 40 L 18 40 Z" fill="#050e1c" stroke="rgba(16, 185, 129, 0.4)" stroke-width="1"/>
            <rect x="12" y="48" width="22" height="6" rx="2" fill="#10b981" filter="url(#neonGlowEmerald)"/>
            <rect x="62" y="48" width="22" height="6" rx="2" fill="#10b981" filter="url(#neonGlowEmerald)"/>
            <rect x="37" y="52" width="22" height="8" rx="1.5" fill="#ffffff"/>
            <text x="48" y="58" text-anchor="middle" fill="#065f46" font-size="5.5" font-weight="900" font-family="'Segoe UI', sans-serif">PARKED</text>
        </g>

        {render_hud_telemetry("YOU HAVE ARRIVED! 🏁", "Journey Complete • Safely At Destination", icon="🏁", lane_type="straight")}
        </svg>"""

    # 4. SCENE: START / DEPART
    elif dt == "START" or "start" in headline.lower():
        return f"""<svg viewBox="0 0 760 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block; max-height: 290px; background: #050a14;">
        {defs}
        {sky_and_horizon}

        <!-- Wide Open Highway Heading Out -->
        <polygon points="345,135 415,135 600,300 160,300" fill="url(#asphaltGrad)"/>
        <line x1="345" y1="135" x2="160" y2="300" stroke="#f8fafc" stroke-width="2.5" opacity="0.8"/>
        <line x1="415" y1="135" x2="600" y2="300" stroke="#f8fafc" stroke-width="2.5" opacity="0.8"/>

        <!-- Dual Powerful Headlight Beams Sweeping Across Asphalt -->
        <polygon points="360,250 340,145 375,145 372,250" fill="url(#headlightBeam)"/>
        <polygon points="400,250 385,145 420,145 412,250" fill="url(#headlightBeam)"/>

        <!-- Starting Gate Holographic Line -->
        <ellipse cx="380" cy="245" rx="120" ry="25" fill="none" stroke="#10b981" stroke-width="2.5" stroke-dasharray="12,8" filter="url(#neonGlowEmerald)"/>

        <!-- Glowing Straight AR Path -->
        <polygon points="370,140 390,140 415,300 345,300" fill="url(#arCarpetStraight)" filter="url(#neonGlowEmerald)" opacity="0.85"/>
        
        <!-- Forward Chevrons -->
        <g fill="#ffffff" opacity="0.95" filter="url(#dropShadow)">
            <polygon points="380,260 370,270 375,273 380,267 385,273 390,270"/>
            <polygon points="380,225 372,233 376,235 380,230 384,235 388,233"/>
            <polygon points="380,190 374,196 377,198 380,194 383,198 386,196"/>
            <polygon points="380,160 376,164 378,165 380,162 382,165 384,164"/>
        </g>

        <!-- Driver Vehicle Ready for Departure -->
        <g filter="url(#dropShadow)" transform="translate(335, 220)">
            <path d="M 12 28 C 12 12 28 4 48 4 C 68 4 84 12 84 28 L 92 65 C 92 68 88 70 82 70 L 14 70 C 8 70 4 68 4 65 Z" fill="#0f1f38" stroke="#38bdf8" stroke-width="1.5"/>
            <path d="M 22 26 C 22 15 32 10 48 10 C 64 10 74 15 74 26 L 78 40 L 18 40 Z" fill="#050e1c" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1"/>
            <rect x="12" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <rect x="62" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <!-- Front Headlights (Glow White/Cyan) -->
            <circle cx="16" cy="12" r="4" fill="#ffffff" filter="url(#neonGlowCyan)"/>
            <circle cx="80" cy="12" r="4" fill="#ffffff" filter="url(#neonGlowCyan)"/>
            <rect x="37" y="52" width="22" height="8" rx="1.5" fill="#ffffff"/>
            <text x="48" y="58" text-anchor="middle" fill="#0f172a" font-size="5.5" font-weight="900" font-family="'Segoe UI', sans-serif">START</text>
        </g>

        {render_hud_telemetry("START JOURNEY 🟢", road_clean, icon="🟢", lane_type="straight")}
        </svg>"""

    # 5. SCENE: STRAIGHT / PROCEED (Long Open Highway Cruise)
    else:
        return f"""<svg viewBox="0 0 760 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="border-radius: 12px; display: block; max-height: 290px; background: #050a14;">
        {defs}
        {sky_and_horizon}

        <!-- 4-Lane Wide Realistic Highway Stretching to Vanishing Point -->
        <polygon points="345,135 415,135 620,300 140,300" fill="url(#asphaltGrad)"/>
        
        <!-- Outer White Fog Lines -->
        <line x1="345" y1="135" x2="140" y2="300" stroke="#f8fafc" stroke-width="3" opacity="0.85"/>
        <line x1="415" y1="135" x2="620" y2="300" stroke="#f8fafc" stroke-width="3" opacity="0.85"/>

        <!-- Dual Yellow Center Divider -->
        <line x1="380" y1="135" x2="380" y2="300" stroke="#facc15" stroke-width="2.5" opacity="0.8"/>
        <line x1="383" y1="135" x2="384" y2="300" stroke="#facc15" stroke-width="2.5" opacity="0.8"/>

        <!-- Lane 1 Dashed Markings -->
        <line x1="362" y1="135" x2="260" y2="300" stroke="#ffffff" stroke-width="2" stroke-dasharray="14,16" opacity="0.75"/>
        <!-- Lane 2 Dashed Markings -->
        <line x1="398" y1="135" x2="500" y2="300" stroke="#ffffff" stroke-width="2" stroke-dasharray="14,16" opacity="0.75"/>

        <!-- 3D Augmented Reality Center Carpet Trajectory -->
        <polygon points="368,140 392,140 435,300 325,300" fill="url(#arCarpetStraight)" filter="url(#neonGlowEmerald)" opacity="0.88"/>
        
        <!-- Forward Animated-style AR Chevrons -->
        <g fill="#ffffff" opacity="0.95" filter="url(#dropShadow)">
            <polygon points="380,265 368,276 374,279 380,272 386,279 392,276"/>
            <polygon points="380,230 370,239 375,241 380,236 385,241 390,239"/>
            <polygon points="380,195 373,202 376,204 380,200 384,204 387,202"/>
            <polygon points="380,165 375,170 377,172 380,168 383,172 385,170"/>
        </g>

        <!-- Arched Highway Streetlight Poles on Both Sides -->
        <!-- Left Streetlight -->
        <path d="M 175 130 Q 170 80 198 75" fill="none" stroke="#64748b" stroke-width="3"/>
        <line x1="175" y1="130" x2="165" y2="225" stroke="#475569" stroke-width="3"/>
        <ellipse cx="200" cy="75" rx="6" ry="2.5" fill="#38bdf8"/>
        <ellipse cx="230" cy="225" rx="75" ry="24" fill="#38bdf8" opacity="0.12" filter="url(#neonGlowCyan)"/>

        <!-- Right Streetlight -->
        <path d="M 585 130 Q 590 80 562 75" fill="none" stroke="#64748b" stroke-width="3"/>
        <line x1="585" y1="130" x2="595" y2="225" stroke="#475569" stroke-width="3"/>
        <ellipse cx="560" cy="75" rx="6" ry="2.5" fill="#38bdf8"/>
        <ellipse cx="530" cy="225" rx="75" ry="24" fill="#38bdf8" opacity="0.12" filter="url(#neonGlowCyan)"/>

        <!-- Highway Guardrails with Amber Cat-Eyes -->
        <line x1="335" y1="135" x2="120" y2="300" stroke="#64748b" stroke-width="4.5" opacity="0.7"/>
        <circle cx="280" cy="175" r="2" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="220" cy="225" r="2.5" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="160" cy="275" r="3" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>

        <line x1="425" y1="135" x2="640" y2="300" stroke="#64748b" stroke-width="4.5" opacity="0.7"/>
        <circle cx="480" cy="175" r="2" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="540" cy="225" r="2.5" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>
        <circle cx="600" cy="275" r="3" fill="#f59e0b" filter="url(#amberBlinkerGlow)"/>

        <!-- Overhead Highway Sign Gantry -->
        <g filter="url(#dropShadow)" transform="translate(210, 68)">
            <line x1="-10" y1="6" x2="350" y2="6" stroke="#475569" stroke-width="3"/>
            <line x1="-10" y1="18" x2="350" y2="18" stroke="#475569" stroke-width="2"/>
            <line x1="0" y1="6" x2="0" y2="60" stroke="#334155" stroke-width="3.5"/>
            <line x1="340" y1="6" x2="340" y2="60" stroke="#334155" stroke-width="3.5"/>
            
            <rect x="35" y="0" width="270" height="42" rx="4" fill="url(#signGrad)" stroke="#f8fafc" stroke-width="1.8"/>
            <text x="170" y="16" text-anchor="middle" fill="#facc15" font-size="9" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">⬆️ CRUISE STRAIGHT • {dist_display.upper()}</text>
            <text x="170" y="32" text-anchor="middle" fill="#ffffff" font-size="12" font-weight="900" font-family="'Segoe UI', Roboto, sans-serif">{road_display}</text>
        </g>

        <!-- Driver Vehicle Cruising Forward -->
        <g filter="url(#dropShadow)" transform="translate(335, 220)">
            <path d="M 12 28 C 12 12 28 4 48 4 C 68 4 84 12 84 28 L 92 65 C 92 68 88 70 82 70 L 14 70 C 8 70 4 68 4 65 Z" fill="#0f1f38" stroke="#38bdf8" stroke-width="1.2"/>
            <path d="M 22 26 C 22 15 32 10 48 10 C 64 10 74 15 74 26 L 78 40 L 18 40 Z" fill="#050e1c" stroke="rgba(56, 189, 248, 0.4)" stroke-width="1"/>
            <rect x="12" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <rect x="62" y="48" width="22" height="6" rx="2" fill="#ef4444" filter="url(#redLightGlow)"/>
            <rect x="37" y="52" width="22" height="8" rx="1.5" fill="#ffffff"/>
            <text x="48" y="58" text-anchor="middle" fill="#0f172a" font-size="5.5" font-weight="900" font-family="'Segoe UI', sans-serif">AP 07</text>
        </g>

        {render_hud_telemetry("GO STRAIGHT ⬆️", road_clean, icon="⬆️", lane_type="straight")}
        </svg>"""

if __name__ == "__main__":
    html_out = "<html><body style='background:#050b14; color:#fff; font-family:sans-serif; padding:20px;'>"
    for dt, title in [("LEFT", "Turn left onto Grand Trunk Road"), ("RIGHT", "Turn right onto Guntur Bypass"), ("STRAIGHT", "Cruise straight on NH16"), ("ARRIVE", "Safely arrive at Vignan University"), ("START", "Head out on corridor")]:
        html_out += f"<h3>{dt}: {title}</h3>"
        html_out += build_realistic_svg(dt, title, "Grand Trunk Road", "1.7 km", 48, 57)
        html_out += "<br><br>"
    html_out += "</body></html>"
    with open("scratch/preview_realistic_svg.html", "w", encoding="utf-8") as f:
        f.write(html_out)
    print("Generated scratch/preview_realistic_svg.html successfully!")
