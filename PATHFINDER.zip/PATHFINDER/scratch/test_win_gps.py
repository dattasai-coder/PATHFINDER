import subprocess

def get_windows_gps():
    try:
        ps_script = """
        Add-Type -AssemblyName System.Device
        $w = New-Object System.Device.Location.GeoCoordinateWatcher
        $w.Start()
        Start-Sleep -Milliseconds 800
        $c = $w.Position.Location
        if (-not $c.IsUnknown) {
            Write-Output "$($c.Latitude),$($c.Longitude)"
        }
        $w.Stop()
        """
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=3
        )
        line = r.stdout.strip()
        if line and "," in line:
            parts = line.split(",")
            return float(parts[0]), float(parts[1])
    except Exception as e:
        pass
    return None

if __name__ == "__main__":
    coords = get_windows_gps()
    print("Windows GPS detected:", coords)
